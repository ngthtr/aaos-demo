# Add this line in \device\generic\car\sdk_car_x86_64.mk
$(call inherit-product, hardware/example_service/example_service.mk)

# Add this line in \common-modules\virtual-device\BUILD.bazel
kernel_build(
    ...   
    visibility = ["//common-modules/virtual-device/example_driver:__pkg__"],
)

kernel_module_group(
    srcs = [
   	...
        "//common-modules/virtual-device/example_driver:example_driver",
    ],
)