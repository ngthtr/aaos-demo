#include "../inc/ExampleService.hpp"
#include <utils/Log.h>

ScopedAStatus ExampleService::registerListener(const std::shared_ptr<IExampleListener>& listener)
{
    ALOGD("registerListener is called");
    if (listener == nullptr)
    {
        ALOGD("listener is null");
        return ndk::ScopedAStatus::ok();
    }
    listener->notifyEvent(1);
    ALOGD("notify respond event when registering successfully");
    return ndk::ScopedAStatus::ok();
}

ScopedAStatus ExampleService::unregisterListener(const std::shared_ptr<IExampleListener>& listener)
{
    ALOGD("unregisterListener is called");
    if (listener == nullptr)
    {
        ALOGD("listener is null");
        return ndk::ScopedAStatus::ok();
    }
    listener->notifyEvent(0);
    ALOGD("notify respond event when unregistering successfully");
    return ndk::ScopedAStatus::ok();
}

ScopedAStatus ExampleService::readDeviceFile() 
{
    ALOGD("readDeviceFile is called");
    mDriverHandler->readFile(pathExampleDriver);
    return ndk::ScopedAStatus::ok();
}

ScopedAStatus ExampleService::writeDeviceFile(const std::string& data) 
{
    ALOGD("writeDeviceFile is called");
    mDriverHandler->writeFile(pathExampleDriver, data.c_str());
    return ndk::ScopedAStatus::ok();
}
